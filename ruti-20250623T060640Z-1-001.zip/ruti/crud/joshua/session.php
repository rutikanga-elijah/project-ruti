<?php
SESSION_START();
if([$_REQUEST_METHOD]==="POST"){
    
$user=$_POST['username'];
$pass=$_POST['pass'];
$select="SELECT*FROM `student`WHERE SELECT `name`='$user',`password`=$pass,";
$exec=mysqli_query($connect,$select);

if(mysqli_fetch_) 

}




?>
<head>
    <link rel="stylesheet" href="form.css">
</head>
<body>

<fieldset>
    <form action=""method="POST">
        <h1>fill login form</h1>
        <input type="text"name="username"value=""placeholder="Entrer your name"><br><br>
        <input type="password"name="pass"placeholder="Entrer your password"><br><br>
        <input type="submit" value="submit">
    </form>
    </fieldset.style>
</body>
</html>