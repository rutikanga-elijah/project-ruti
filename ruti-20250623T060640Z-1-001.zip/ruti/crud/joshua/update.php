<?php
include 'config.php';
if(isset($_GET)){
    $id=$_GET['sid'];
    $select="SELECT * FROM `student` WHERE id='$id'";
    $result=mysqli_query($connect,$select);
    $user=mysqli_fetch_array($result);
}

 if($_SERVER['REQUEST_METHOD']== "POST"){
    $user=$_POST['name'];
    $email=$_POST['email'];
    $course=$_POST['course'];
    if (empty($email)) {
        die("Error: Email cannot be empty.");
    }
    $update="UPDATE `student` SET `name`='$user',`email`='$email',`course`='$course' WHERE id='$id'";
    $exec=mysqli_query($connect,$update);
    if($exec){
        header('location:retrive.php');
    }
    else{
        echo "error due to updating";
    }
 }



?>

    <form action="" method="post">
     Name <input type="text" name="name" value="<?php echo $user['1'];?>"><br><br>
     Email <input type="email" name="email" value="<?php echo $user['2'];?>"><br><br>
     Course <input type="text" name="course" value="<?php echo $user['3'];?>"><br><br>
     <button type="submit">Update</button>
    </form>
