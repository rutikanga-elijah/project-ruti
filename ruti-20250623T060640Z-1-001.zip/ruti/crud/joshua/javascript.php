<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>hello to javascrip</h1>
    <script>
        
        // var name=prompt("enter your name");
        // var age=prompt("enter your age");
        // if(age>=18){
        //     console.log("hello".name+"".age+"you are allowed to egt marriage")
        // }
        // else{
        //     console.log("hello".name+"".age+"you are  not allowed to get marriage")
        // }
        
    // for(var row=1;(row<=6);row++){
    // for(var col=1;col<= row;col++){
   
    //                    document.write("*")
    //                    document.write("<br>")

                    
                    
    //                 }
    //             }
    for(var row=5;row<=1;row--)
    for(var col=5;col<=row;col--){
document.write("#")
document.write("<br>")

    }
    </script>
    
</body>
</html>