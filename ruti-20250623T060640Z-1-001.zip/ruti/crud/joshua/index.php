<!-- <?php
$user=$_POST['usern'];
$email=$_POST['email'];
$age=$_POST[''];
$pass=$_POST['passs'];
$conf=$_POST['confirm'];
if(empty($user)||empty($email)){
    echo"fill this name field";

}
elseif(!is_numeric($age)){
    echo"age must be a numebr";
}
else if($conf!==$pass){
    echo"Your password not match please try again!!!";
   }

    elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo"this email is invalid";
    }

else{
    echo"welcome".$user.""."to our website";    
}
?>  -->
<?php
include 'config.php';
    $user=$_POST['user'];
    $email=$_POST['email'];
    $course=$_POST['course'];
if($connect){
   echo"database connected!!";
}
else{
    echo"user not inserted";
  
}
?>