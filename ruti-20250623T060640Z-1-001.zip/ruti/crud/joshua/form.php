<?php
include'config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
$user=$_POST['user'];
$email=$_POST['email'];
$course=$_POST['course'];
$insert="INSERT INTO `student`VALUES('','$user','$email','$course')"; 
$exec=mysqli_query($connect,$insert);
if($exec){
    echo"user ceated successfully";

}
else{
    echo"user not created";
}

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="form.css">
</head>
<body>
    
    <fieldset align="center">
    <h1>   FILL THIS LOGIN</h1><BR></BR>
    <form method="POST"action="">
    <input type="text"name="user"placeholder="enter your name"  required><br><br>
   <input type="email"name="email"placeholder="enter your email"  required><br><br>
   <input type="text"name="course" placeholder="enter course"  required><br><br>
    
    <center><button type="submit">submit</button></center>
 </form>
 </fieldset>
 <center> <a href="retrive.php"><button class="b1">view user</button></a>
 </center>

</body>
</html>

