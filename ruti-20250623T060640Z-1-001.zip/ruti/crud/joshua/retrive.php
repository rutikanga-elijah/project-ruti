
    <table border="1"align="center">
        <thead bgcolor="greenyellow">
            <tr>
                <td>ID</td>
                <td>name</td>
                <td>email</td>
                <td>course</td>
                <td>action</td>
            </tr>
        </thead>
        <?php
        include'config.php';
        $sql="SELECT* FROM `student`";
        $result=mysqli_query($connect,$sql);
        if(mysqli_num_rows($result)>0){
            while($row=mysqli_fetch_array($result)){
                ?>
            <tbody>
                <td><?php echo $row[0];?></td>
                <td><?php echo $row[1];?></td>
                <td><?php echo $row[2];?></td>
                <td><?php echo $row[3];?></td>
              <td><a href="delete.php?sid=<?php echo $row['0'];?>"><button>Delete</button></a> 
              <a href="update.php?sid=<?php echo $row['0'];?>"><button>update</button></a></td>  
            </tbody>
            <?php

            }
        }
        else{
          echo"no user record found!!!";
        }
        ?>
    </table><br><br>
   <center> <a href="form.php"><button>add new user!!</button></a></center>
    <link rel="stylesheet" href="form.css">
</center>
  