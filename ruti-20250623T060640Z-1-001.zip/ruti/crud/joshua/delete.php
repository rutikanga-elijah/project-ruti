<?php
include('config.php');

$id=$_GET['sid'];
$delete="DELETE FROM `student` WHERE `id`='$id'";
$exec=mysqli_query($connect,$delete);
if($exec){
    header('location:retrive.php');
}
else{
    echo "user not deleted";
}



?>