<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("INSERT INTO attend ()  VALUES (?, ?)");
    $stmt->bind_param("ss", $name, $email);

    if ($stmt->execute()) {
        header("Location: index.php");
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Add New User</h1>
    <form action="create.php" method="POST">
        <label for="name">Name:</label><br>
        <input type="text" name="name" required><br>
        <label for="email">Email:</label><br>
        <input type="email" name="email" required><br><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>
